# sentiment anaysis ----------------------------------------------------------------------------------------
# create lists of positive and negative words using Hu and Liu (2004) lists
import os  # operating system commands
import re  # regular expressions
import nltk  # draw on the Python natural lanencoding="ISO-8859-1"):guage toolkit
from nltk.corpus import PlaintextCorpusReader
import pandas as pd 
from pandas import DataFrame, read_csv


my_directory = 'C:/Users/jza713/452_red_project'
positive_list = PlaintextCorpusReader(my_directory, 'Hu_Liu_positive_word_list.txt')
negative_list = PlaintextCorpusReader(my_directory, 'Hu_Liu_negative_word_list.txt')
positive_words = positive_list.words()
negative_words = negative_list.words()

# define bag-of-words dictionaries 
def bag_of_words(words, value):
    return dict([(word, value) for word in words])
positive_scoring = bag_of_words(positive_words, 1)
negative_scoring = bag_of_words(negative_words, -1)
scoring_dictionary = dict(positive_scoring.items() + negative_scoring.items())

# identify all of the directory names 
nfiles = 0
dir_names = [name for name in 
    os.listdir('/Users/jza713/452_red_project/redteam_all/')
    if os.path.isdir(os.path.join('/Users/jza713/452_red_project/redteam_all/', name))]
print('\nInput Directory Names') 
print(dir_names)

os.mkdir('/Users/jza713/452_red_project/red_daily_sentiment/' + 'daily_sentiment6') 

for input_dir in dir_names:
    # indentify all text files in this directory
    text_names = None  # initialize file name list for this directory
    text_names = [name for name in 
        os.listdir(os.path.join('/Users/jza713/452_red_project/redteam_all/', input_dir)) 
        if name.endswith('.txt')]
    print('\nWorking on directory: ')
    print(input_dir)
    print(text_names)
    
# work on files one at a time
    for input_file in text_names:
        # read in the original text file
        this_dir = os.path.join('/Users/jza713/452_red_project/redteam_all/', input_dir)
        with open(os.path.join(this_dir, input_file),'rt') as ff:
            my_text = ff.read()              
            corpus = my_text.split()
            score_posi = [0] * len(corpus) 
            score_neg = [0] * len(corpus) 
            for iword in range(len(corpus)):
               if corpus[iword] in positive_scoring:
                  score_posi[iword] = positive_scoring[corpus[iword]]       
               if corpus[iword] in negative_scoring:
                  score_neg[iword] = negative_scoring[corpus[iword]]        
            A1 = len(corpus)
            A2 = sum(score_posi)
            A3 = abs(sum(score_neg)) 
            A4 = round(float(sum(score_posi)) / (float(len(corpus))), 4)
            A5 = abs(round(float(sum(score_neg)) / (float(len(corpus))), 4))         
            total = A1
            positive = A2
            negative = A3
            posi_perc = A4
            nega_perc = A5
            chip_tac= str(total)+' '+str(positive)+" "+str(negative)+" "+str(posi_perc)+' '+str(nega_perc)+' '
            #chip_tac= [total,positive,negative,posi_perc,nega_perc] 
            # writeto new files with extension .csv
            output_file_name = input_file
            output_file = '/Users/jza713/452_red_project/red_daily_sentiment/daily_sentiment6/' +output_file_name
            with open(output_file, 'wt') as f:
                f.write(chip_tac) 
                nfiles = nfiles + 1

print('\n\nRUN COMPLETE ' + str(nfiles) + ' files in total (see directory <results>)')    

import csv
import itertools

from os import listdir

dirname = '/Users/smuthurangan/Desktop/MSPA/MSPA452/teamproject/redteamdepo/daily_sentiment_Subb/taco17/'

datesince = ['2017-08-01', '2017-08-02', '2017-08-03', '2017-08-04', '2017-08-05', '2017-08-06',
             '2017-08-07', '2017-08-08', '2017-08-09', '2017-08-10', '2017-08-11', '2017-08-12',
             '2017-08-13', '2017-08-14', '2017-08-15', '2017-08-16', '2017-08-17', '2017-08-18',
             '2017-08-19', '2017-08-20', '2017-08-21', '2017-08-22', '2017-08-23', '2017-08-24',
             '2017-08-25', '2017-08-26', '2017-08-27', '2017-08-28', '2017-08-29', '2017-08-30', '2017-08-31',
             '2017-09-01', '2017-09-02', '2017-09-03', '2017-09-04', '2017-09-05', '2017-09-06',
             '2017-09-07', '2017-09-08', '2017-09-09', '2017-09-10', '2017-09-11', '2017-09-12',
             '2017-09-13', '2017-09-14', '2017-09-15', '2017-09-16', '2017-09-17', '2017-09-18',
             '2017-09-19', '2017-09-20', '2017-09-21', '2017-09-22', '2017-09-23', '2017-09-24',
             '2017-09-25', '2017-09-26', '2017-09-27', '2017-09-28', '2017-09-29', '2017-09-30',
             '2017-10-01', '2017-10-02', '2017-10-03', '2017-10-04', '2017-10-05', '2017-10-06',
             '2017-10-07', '2017-10-08', '2017-10-09', '2017-10-10', '2017-10-11', '2017-10-12',
             '2017-10-13', '2017-10-14', '2017-10-15', '2017-10-16', '2017-10-17', '2017-10-18',
             '2017-10-19', '2017-10-20', '2017-10-21', '2017-10-22', '2017-10-23', '2017-10-24',
             '2017-10-25', '2017-10-26', '2017-10-27', '2017-10-28', '2017-10-29', '2017-10-30', '2017-10-31']
counter = 0
for file in listdir(dirname):
    print(dirname + file)
    with open(dirname + file, 'r') as in_file:
        for line in in_file:
            line = line.replace(" ", ",")[:-1]
            line = datesince[counter] + "," + line
            print(line)
        with open('taco2017.csv', 'a') as out_file:
            writer = csv.writer(out_file)
            if counter == 0:
                writer.writerow(('Date','Total Words', 'Positive Words', 'Negative Words', 'Positive Score', 'Negative Score'))
            writer.writerow(line.split(","))
        counter = counter + 1