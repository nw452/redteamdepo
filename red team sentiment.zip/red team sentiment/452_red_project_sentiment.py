# sentiment anaysis ----------------------------------------------------------------------------------------
# create lists of positive and negative words using Hu and Liu (2004) lists
import os  # operating system commands
import re  # regular expressions
import nltk  # draw on the Python natural lanencoding="ISO-8859-1"):guage toolkit
from nltk.corpus import PlaintextCorpusReader

my_directory = 'C:/Users/jza713/452_red_project'
positive_list = PlaintextCorpusReader(my_directory, 'Hu_Liu_positive_word_list.txt')
negative_list = PlaintextCorpusReader(my_directory, 'Hu_Liu_negative_word_list.txt')
positive_words = positive_list.words()
negative_words = negative_list.words()

# define bag-of-words dictionaries 
def bag_of_words(words, value):
    return dict([(word, value) for word in words])
positive_scoring = bag_of_words(positive_words, 1)
negative_scoring = bag_of_words(negative_words, -1)
scoring_dictionary = dict(positive_scoring.items() + negative_scoring.items())

# identify all of the file names 
file_names =  os.listdir(my_directory + '/chipotle/')
nfiles = len(file_names)  #
print(nfiles) 

# Create a single corpus by combining the files(August-October)--Chipotle.  
for ifile in range(len(file_names)):
    this_file_name = 'C:/Users/jza713/452_red_project/chipotle/' + file_names[ifile]
    with open(this_file_name, 'rt') as f:
        this_file_text = f.read()
corpus = this_file_text.split() 
 
# list for assigning a score to every word in the corpus
# scores are -1 if in negative word list, +1 if in positive word list
# and zero otherwise. We use a dictionary for scoring.

score_posi = [0] * len(corpus)  # initialize scoring list
for iword in range(len(corpus)):
    if corpus[iword] in positive_scoring:
        score_posi[iword] = positive_scoring[corpus[iword]]       
# report sentiment score for the words(positive) in the corpus
print(sum(score_posi))
print(round(float(sum(score_posi)) / (float(len(corpus))), 4)) 

# negative
score_neg = [0] * len(corpus)  # initialize scoring list
for iword in range(len(corpus)):
    if corpus[iword] in negative_scoring:
        score_neg[iword] = negative_scoring[corpus[iword]]        
# report sentiment score for the words(negative) in the corpus
print(len(corpus))
print(sum(score_neg))
print(round(float(sum(score_neg)) / (float(len(corpus))), 4)) 

# Create a single corpus by combining the files(August-October)--Noodles.  
file_names =  os.listdir(my_directory + '/noodles/')
nfiles = len(file_names)  #
print(nfiles)

for ifile in range(len(file_names)):
    this_file_name = 'C:/Users/jza713/452_red_project/noodles/' + file_names[ifile]
    with open(this_file_name, 'rt') as f:
        this_file_text = f.read()
corpus = this_file_text.split() 

score_posi = [0] * len(corpus)  # initialize scoring list
for iword in range(len(corpus)):
    if corpus[iword] in positive_scoring:
        score_posi[iword] = positive_scoring[corpus[iword]]       
# report sentiment score for the words(positive) in the corpus
print(sum(score_posi))
print(round(float(sum(score_posi)) / (float(len(corpus))), 4)) 

# negative
score_neg = [0] * len(corpus)  # initialize scoring list
for iword in range(len(corpus)):
    if corpus[iword] in negative_scoring:
        score_neg[iword] = negative_scoring[corpus[iword]]        
# report sentiment score for the words(negative) in the corpus
print(len(corpus))
print(sum(score_neg))
print(round(float(sum(score_neg)) / (float(len(corpus))), 4)) 


# Create a single corpus by combining the files(August-October)--taco.  
file_names =  os.listdir(my_directory + '/taco/')
nfiles = len(file_names)  #
print(nfiles)

for ifile in range(len(file_names)):
    this_file_name = 'C:/Users/jza713/452_red_project/taco/' + file_names[ifile]
    with open(this_file_name, 'rt') as f:
        this_file_text = f.read()
corpus = this_file_text.split() 

score_posi = [0] * len(corpus)  # initialize scoring list
for iword in range(len(corpus)):
    if corpus[iword] in positive_scoring:
        score_posi[iword] = positive_scoring[corpus[iword]]       
# report sentiment score for the words(positive) in the corpus
print(sum(score_posi))
print(round(float(sum(score_posi)) / (float(len(corpus))), 4)) 

# negative
score_neg = [0] * len(corpus)  # initialize scoring list
for iword in range(len(corpus)):
    if corpus[iword] in negative_scoring:
        score_neg[iword] = negative_scoring[corpus[iword]]        
# report sentiment score for the words(negative) in the corpus
print(len(corpus))
print(sum(score_neg))
print(round(float(sum(score_neg)) / (float(len(corpus))), 4)) 


