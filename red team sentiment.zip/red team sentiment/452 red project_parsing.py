import os  # operating system commands
import re  # regular expressions
import nltk  # draw on the Python natural lanencoding="ISO-8859-1"):guage toolkit
from nltk.corpus import PlaintextCorpusReader
from numpy import *  # for array calculations
from collections import Counter

# text parsing function for creating cleaned-text document
#-----------------------------------------------------------------------
# define list of codes to be dropped from document
# carriage-returns, line-feeds, tabs
codelist = ['\r', '\n', '\t']    
# there are certain words we will ignore in subsequent text processing... 
nltk.download('stopwords')
# remove negations from standard stopwords list
# negations can be important in sentiment analysis
negations = ['no', 'nor', 'not']
oldlist = nltk.corpus.stopwords.words('english')
stoplist = [x for x in oldlist if x not in negations ]

# text parsing function for creating cleaned-text document 
def text_parse(string):
    # replace non-alphanumeric with space 
    temp_string = re.sub('[^a-zA-Z]', '  ', string)    
    # replace codes with space
    for i in range(len(codelist)):
        stopstring = ' ' + codelist[i] + '  '
        temp_string = re.sub(stopstring, '  ', temp_string)      
    # replace single-character words with space
    temp_string = re.sub('\s.\s', ' ', temp_string)   
    # convert uppercase to lowercase
    temp_string = temp_string.lower()    
    # replace selected character strings/stop-words with space
    for i in range(len(stoplist)):
        stopstring = ' ' + stoplist[i] + ' '
        temp_string = re.sub(stopstring, ' ', temp_string)        
    # replace multiple blank characters with one blank character
    temp_string = re.sub('\s+', ' ', temp_string)    
    return(temp_string) 
              
# initialize count of results files
nfiles = 0
# identify all of the directory names 
dir_names = [name for name in 
    os.listdir('/Users/jza713/452_red_project/redteamdepo_smuthurangan_all/')
    if os.path.isdir(os.path.join('/Users/jza713/452_red_project/redteamdepo_smuthurangan_all/', name))]
print('\nInput Directory Names') 
  
# create a directory for red_chipotle1... called red_chipotle1
os.mkdir('/Users/jza713/452_red_project/' + 'red_chipotle1') 
print(dir_names)

for input_dir in dir_names:
    # indentify all text files in this directory
    text_names = None  # initialize file name list for this directory
    text_names = [name for name in 
        os.listdir(os.path.join('/Users/jza713/452_red_project/redteamdepo_smuthurangan_all/', input_dir)) 
        if name.endswith('.txt')]
    print('\nWorking on directory: ')
    print(input_dir)
    print(text_names)
    
# work on files one at a time
    for input_file in text_names:
        # read in the original text file
        this_dir = os.path.join('/Users/jza713/452_red_project/redteamdepo_smuthurangan_all/', input_dir)
        with open(os.path.join(this_dir, input_file),'rt') as ff:
            my_text = ff.read()
            
            # parse the text to prepare for subsequent document processing
            my_document = text_parse(my_text)                
        
            # write text to new files with extension .txt 
            output_file_name = input_file
            output_file = '/Users/jza713/452_red_project/red_chipotle1/' +output_file_name
            with open(output_file, 'wt') as f:
                f.write(str(my_document))
                nfiles = nfiles + 1
                
print('\n\nRUN COMPLETE ' + str(nfiles) + ' files in total (see directory <results>)')    
 
        
       
        